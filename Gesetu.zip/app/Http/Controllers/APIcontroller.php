<?php

namespace App\Http\Controllers;
use App\Personne;
use Illuminate\Http\Request;

class APIcontroller extends Controller
{
   public function Personne(){
       $Personnes=Personne::all();
        return response()->json($Personnes,200);
       }
}
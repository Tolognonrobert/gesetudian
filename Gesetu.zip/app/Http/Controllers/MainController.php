<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\MainController;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Mail\SignUpMail;

class MainController extends Controller
{
    //traitement de la racine
    public function index(){
         return view('accueil');
    }
        
     public function demo(){
      
          
    
       return view('demo');

     }
    public function inscription(){
       
      $fillieres= DB::table("Fillieres")->get();
      return view('inscription',compact('fillieres'));

    }
    public function connexion(){
        return view('connexion');
    }
    public function verification_connexion(){

      $this->validate($request,
      [
       
       "email"=>"required|email",
       "password"=>"required|min:8|alpha_num",
       "cpassword"=>"required|same:password|min:8|alpha_num"
      ]);
 
    }
    public function verification_inscription(Request $request){
    //dd($request->input('toto'));
     $this->validate($request,
     [
      "nom"=>"required|alpha|min:2",
      "prenom"=>"required|alpha|min:2",
      "pseudo"=>"required|alpha|min:2",
      "email"=>"required|email",
      "password"=>"required|min:8|alpha_num",
      "cpassword"=>"required|same:password|min:8|alpha_num"
     ]);

     $inscription= DB::table('Etudiants')->insert(
                              ["nom"=>$request->nom,
                              "prenom"=>$request->prenom,
                              "pseudo"=>$request->pseudo,
                              "email"=>$request->email,
                              "password"=>$request->password,
                              "code_fil"=>$request->toto
                              ]
                            );

                            if($inscription){

                              Mail::to($request->email)->send(new SignUpMail($request->nom,$request->prenom));
                            }
     
    

    }
    
}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=h, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("css/materialize.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    <title>Accueil</title>
</head>
<body>
    <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="<?php echo e(route("index")); ?>" class="brand-logo"> Gesetu</a>
          <ul class="right hide-on-med-and-down">
          <li><a href="<?php echo e(route("connexion")); ?>">Se connecter</a></li>
          <li><a href="<?php echo e(route("inscription")); ?>">S'inscrire</a></li>
          </ul>
    
          <ul id="nav-mobile" class="sidenav">
            <li><a href="<?php echo e(route("connexion")); ?>">Se connecter</a></li>
          <li><a href="<?php echo e(route("inscription")); ?>">S'inscrire</a></li>
          </ul>
          <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        </div>
      </nav>
      <div class="section no-pad-bot" id="index-banner">
        <div class="container">
          <br><br>
          <h1 class="header center orange-text">Gestion des etudiant</h1>
          <div class="row center">
            <h5 class="header col s12 light"> Bienvenu sur la plateforme des étudiants </h5>
          </div>
          <div class="row center">
          <a href="<?php echo e(route("inscription")); ?>"  class="btn-large waves-effect waves-light orange">Lancez vous</a>
          </div>
          <br><br>
    
        </div>
      </div>
  <!-- Modal Structure -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Modal Header</h4>
      <p>A bunch of text</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Agree</a>
    </div>
    
  </div>
     
      <div class="container">
        <div class="section">
          <!--   Icon Section   -->
            <div class="col s12 m4">
              <div class="icon-block">
                <p class="light"></p>
              </div>
            </div>
          </div>
        </div>
        <br><br>
      </div>

<footer class="page-footer orange">
    
    <div class="container">
        <div class="section">
            <div class="col s12 m4">
              <div class="icon-block">
                <p class="light"> Tout part de votre connexion. vous pouvez : <br> Ajouter les notes <br> Telecharger la liste de vos notes </p>
              </div>
            </div>
          </div>
        </div>
        <br><br>
      </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="orange-text text-lighten-3" href="http://materializecss.com">TOYERO</a>
      </div>
    </div>
  </footer>
</body>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script>
  // jQuery

  $(document).ready(function(){
    $('.modal').hide();
    $('.modal').modal();
  });

</script>
  <!--  Scripts-->
 
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</html><?php /**PATH /home/tolognon/Projets/Gesetudiant/resources/views/accueil.blade.php ENDPATH**/ ?>